Labirinto 3d: por Thiago L. e Marcelo Souza

Intru��es de uso:


Controles:
   seta para direita: vira para direita
   seta para esquerda: vira para esquerda
   seta para cima: avan�a para frente
   seta para baixo: recua
   page up: olha para cima
   page down: olha para baixo
   home: se desloca para cima
   end: se desloca para baixo
   Esq: sai do programa
   f12: ativa/desativa full screen


Formato do arquivo de objetos:
 
1 linha: translacao do objeto no mundo
2 linha: rotacao do objeto no mundo
3 linha: cor do objeto em RGB
4 linha: numero de pontos
5 linha...: sequencia de pontos 3d espacados por espaco em 	    branco(inclusive as coordenadas de um mesmo ponto)
n linha: numero de triangulos formados pelos pontos dados acima
m linha...: sequencia de indices formando triangulos com os pontos
            definidos acima.
(veja arquivo dorso.txt ou labirinto.txt para melhor entender)




